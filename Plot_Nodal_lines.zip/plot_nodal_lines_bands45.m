function h = plot_nodal_lines_bands45(color)
%UNTITLED29 Summary of this function goes here
%   Detailed explanation goes here

%% sigma_h nodal lines
b1=[4,0,0];
b2=[0,4,0];

R1=[0,-1,0;1,0,0;0,0,1];
R2=[0,1,0;0,0,1;1,0,0];
R3=[1,0,0;0,0,-1;0,1,0];
R4=[0,0,1;0,1,0;-1,0,0];

K1K2=load('Nodal_line_bands45_sigma_h.txt');
K1K2=[K1K2;...
    [K1K2(:,1),-K1K2(:,2)];...
    [-K1K2(:,1),K1K2(:,2)];...
    [-K1K2(:,1),-K1K2(:,2)]];
KK1=K1K2*[b1;b2];
KK2=KK1*R2';
KK3=KK2*R2';

scatter3(KK1(:,1),KK1(:,2),KK1(:,3),5,color,'filled')
scatter3(KK2(:,1),KK2(:,2),KK2(:,3),5,color,'filled')
scatter3(KK3(:,1),KK3(:,2),KK3(:,3),5,color,'filled')

%% sigma_d nodal lines
b1=[3,3,0];
b2=[0,0,4];

R1=[0,-1,0;1,0,0;0,0,1];
R2=[0,1,0;0,0,1;1,0,0];

K1K2=load('Nodal_line_bands45.txt');
K1K2=[K1K2;...
    [-K1K2(:,1),K1K2(:,2)];...
    [K1K2(:,1),-K1K2(:,2)];...
    [-K1K2(:,1),-K1K2(:,2)]];
KK1=K1K2*[b1;b2];
KK2=KK1*R1';
KK3=KK2*R2';
KK4=KK3*R2';
KK5=KK1*R2';
KK6=KK5*R2';

scatter3(KK1(:,1),KK1(:,2),KK1(:,3),5,color,'filled')
scatter3(KK2(:,1),KK2(:,2),KK2(:,3),5,color,'filled')
scatter3(KK3(:,1),KK3(:,2),KK3(:,3),5,color,'filled')
scatter3(KK4(:,1),KK4(:,2),KK4(:,3),5,color,'filled')
scatter3(KK5(:,1),KK5(:,2),KK5(:,3),5,color,'filled')
scatter3(KK6(:,1),KK6(:,2),KK6(:,3),5,color,'filled')

end

