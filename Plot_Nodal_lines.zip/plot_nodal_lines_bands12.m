function h=plot_nodal_lines_bands12(color,s)

%% nonsymmorphic nodal lines
plot3([2,2,-2,-2,2],[0,0,0,0,0],[-2,2,2,-2,-2],color,'LineWidth',s)
plot3([0,0,0,0,0],[2,2,-2,-2,2],[-2,2,2,-2,-2],color,'LineWidth',s)
plot3([2,2,-2,-2,2],[-2,2,2,-2,-2],[0,0,0,0,0],color,'LineWidth',s)

% plot3([2,2],[0,0],[1,-1],color,'LineWidth',s)
% plot3([2,2],[1,-1],[0,0],color,'LineWidth',s)
% plot3([1,-1],[2,2],[0,0],color,'LineWidth',s)
% plot3([0,0],[2,2],[1,-1],color,'LineWidth',s)
% plot3([0,0],[1,-1],[2,2],color,'LineWidth',s)
% plot3([1,-1],[0,0],[2,2],color,'LineWidth',s)
% plot3([-2,-2],[0,0],[1,-1],color,'LineWidth',s)
% plot3([-2,-2],[1,-1],[0,0],color,'LineWidth',s)
% plot3([1,-1],[-2,-2],[0,0],color,'LineWidth',s)
% plot3([0,0],[-2,-2],[1,-1],color,'LineWidth',s)
% plot3([0,0],[1,-1],[-2,-2],color,'LineWidth',s)
% plot3([1,-1],[0,0],[-2,-2],color,'LineWidth',s)

%% Gamma-L nodal lines
plot3([1,-1],[1,-1],[1,-1],color,'LineWidth',s)
plot3([1,-1],[1,-1],[-1,1],color,'LineWidth',s)
plot3([1,-1],[-1,1],[1,-1],color,'LineWidth',s)
plot3([-1,1],[1,-1],[1,-1],color,'LineWidth',s)

%% sigma_h nodal lines
Theta=linspace(0,2*pi,100)';
x=0.1909*cos(Theta);
y=0.1909*sin(Theta);
z=zeros(100,1);

plot3(1*x,1*y,z,color,'LineWidth',s)
plot3(1*x,z,1*y,color,'LineWidth',s)
plot3(z,1*x,1*y,color,'LineWidth',s)


b1=[4,0,0];
b2=[0,4,0];

R1=[0,-1,0;1,0,0;0,0,1];
R2=[0,1,0;0,0,1;1,0,0];
R3=[1,0,0;0,0,-1;0,1,0];
R4=[0,0,1;0,1,0;-1,0,0];

K1K2=load('Nodal_line_bands12_sigma_h.txt');
K1K2=[K1K2;...
    [1-K1K2(:,1),K1K2(:,2)];...
    [K1K2(:,1),-K1K2(:,2)];...
    [1-K1K2(:,1),-K1K2(:,2)]];
KK1=K1K2*[b1;b2];
KK2=KK1*R2';
KK3=KK2*R2';
KK4=KK1*R4';
KK5=KK2*R3';
KK6=KK3*R1';



% KK1=mk_KK_new(KK1);
% KK2=mk_KK_new(KK2);
% KK3=mk_KK_new(KK3);
% KK4=mk_KK_new(KK4);
% KK5=mk_KK_new(KK5);
% KK6=mk_KK_new(KK6);

scatter3(KK1(:,1),KK1(:,2),KK1(:,3),5,color,'filled')
scatter3(KK2(:,1),KK2(:,2),KK2(:,3),5,color,'filled')
scatter3(KK3(:,1),KK3(:,2),KK3(:,3),5,color,'filled')
scatter3(KK4(:,1),KK4(:,2),KK4(:,3),5,color,'filled')
scatter3(KK5(:,1),KK5(:,2),KK5(:,3),5,color,'filled')
scatter3(KK6(:,1),KK6(:,2),KK6(:,3),5,color,'filled')
scatter3(-KK1(:,1),-KK1(:,2),-KK1(:,3),5,color,'filled')
scatter3(-KK2(:,1),-KK2(:,2),-KK2(:,3),5,color,'filled')
scatter3(-KK3(:,1),-KK3(:,2),-KK3(:,3),5,color,'filled')
scatter3(-KK4(:,1),-KK4(:,2),-KK4(:,3),5,color,'filled')
scatter3(-KK5(:,1),-KK5(:,2),-KK5(:,3),5,color,'filled')
scatter3(-KK6(:,1),-KK6(:,2),-KK6(:,3),5,color,'filled')

scatter3([KK1(:,1)-2;-KK6(:,1)-2],[KK1(:,2)+2;-KK6(:,2)+2],...
    [KK1(:,3)+2;-KK6(:,3)+2],5,color,'filled')
scatter3([KK1(:,1)-2;-KK6(:,1)-2],[KK1(:,2)-2;-KK6(:,2)-2],...
    [KK1(:,3)+2;-KK6(:,3)+2],5,color,'filled')
scatter3([KK1(:,1)-2;-KK6(:,1)-2],[KK1(:,2)-2;-KK6(:,2)-2],...
    [KK1(:,3)-2;-KK6(:,3)-2],5,color,'filled')
scatter3([KK1(:,1)-2;-KK6(:,1)-2],[KK1(:,2)+2;-KK6(:,2)+2],...
    [KK1(:,3)-2;-KK6(:,3)-2],5,color,'filled')
scatter3([KK3(:,1)+2;-KK5(:,1)+2],[KK3(:,2)-2;-KK5(:,2)-2],...
    [KK3(:,3)+2;-KK5(:,3)+2],5,color,'filled')
scatter3([KK3(:,1)-2;-KK5(:,1)-2],[KK3(:,2)-2;-KK5(:,2)-2],...
    [KK3(:,3)+2;-KK5(:,3)+2],5,color,'filled')
scatter3([KK3(:,1)-2;-KK5(:,1)-2],[KK3(:,2)-2;-KK5(:,2)-2],...
    [KK3(:,3)-2;-KK5(:,3)-2],5,color,'filled')
scatter3([KK3(:,1)+2;-KK5(:,1)+2],[KK3(:,2)-2;-KK5(:,2)-2],...
    [KK3(:,3)-2;-KK5(:,3)-2],5,color,'filled')
scatter3([KK2(:,1)+2;-KK4(:,1)+2],[KK2(:,2)+2;-KK4(:,2)+2],...
    [KK2(:,3)-2;-KK4(:,3)-2],5,color,'filled')
scatter3([KK2(:,1)-2;-KK4(:,1)-2],[KK2(:,2)+2;-KK4(:,2)+2],...
    [KK2(:,3)-2;-KK4(:,3)-2],5,color,'filled')
scatter3([KK2(:,1)-2;-KK4(:,1)-2],[KK2(:,2)-2;-KK4(:,2)-2],...
    [KK2(:,3)-2;-KK4(:,3)-2],5,color,'filled')
scatter3([KK2(:,1)+2;-KK4(:,1)+2],[KK2(:,2)-2;-KK4(:,2)-2],...
    [KK2(:,3)-2;-KK4(:,3)-2],5,color,'filled')


%% sigma_d nodal lines
b1=[3,3,0];
b2=[0,0,4];

R1=[0,-1,0;1,0,0;0,0,1];
R2=[0,1,0;0,0,1;1,0,0];

K1K2=load('Nodal_line_bands12.txt');
K1K2=[K1K2;...
    [-K1K2(:,1),K1K2(:,2)];...
    [K1K2(:,1),-K1K2(:,2)];...
    [-K1K2(:,1),-K1K2(:,2)]];
KK1=K1K2*[b1;b2];
KK2=KK1*R1';
KK3=KK2*R2';
KK4=KK3*R2';
KK5=KK1*R2';
KK6=KK5*R2';

KK1=mk_KK_new(KK1);
KK2=mk_KK_new(KK2);
KK3=mk_KK_new(KK3);
KK4=mk_KK_new(KK4);
KK5=mk_KK_new(KK5);
KK6=mk_KK_new(KK6);

scatter3(KK1(:,1),KK1(:,2),KK1(:,3),5,color,'filled')
scatter3(KK2(:,1),KK2(:,2),KK2(:,3),5,color,'filled')
scatter3(KK3(:,1),KK3(:,2),KK3(:,3),5,color,'filled')
scatter3(KK4(:,1),KK4(:,2),KK4(:,3),5,color,'filled')
scatter3(KK5(:,1),KK5(:,2),KK5(:,3),5,color,'filled')
scatter3(KK6(:,1),KK6(:,2),KK6(:,3),5,color,'filled')



a=24;b=10.2;   % 001 view


view([a,b])

light
lighting gouraud

axis off
axis equal

end