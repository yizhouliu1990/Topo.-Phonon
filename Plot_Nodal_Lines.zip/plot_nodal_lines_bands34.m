function h = plot_nodal_lines_bands34(color,s)
%UNTITLED28 Summary of this function goes here
%   Detailed explanation goes here

%% nonsymmorphic nodal lines
plot3([2,2,-2,-2,2],[0,0,0,0,0],[-2,2,2,-2,-2],color,'LineWidth',s)
plot3([0,0,0,0,0],[2,2,-2,-2,2],[-2,2,2,-2,-2],color,'LineWidth',s)
plot3([2,2,-2,-2,2],[-2,2,2,-2,-2],[0,0,0,0,0],color,'LineWidth',s)

% plot3([2,2],[0,0],[1,-1],color,'LineWidth',s)
% plot3([2,2],[1,-1],[0,0],color,'LineWidth',s)
% plot3([1,-1],[2,2],[0,0],color,'LineWidth',s)
% plot3([0,0],[2,2],[1,-1],color,'LineWidth',s)
% plot3([0,0],[1,-1],[2,2],color,'LineWidth',s)
% plot3([1,-1],[0,0],[2,2],color,'LineWidth',s)
% plot3([-2,-2],[0,0],[1,-1],color,'LineWidth',s)
% plot3([-2,-2],[1,-1],[0,0],color,'LineWidth',s)
% plot3([1,-1],[-2,-2],[0,0],color,'LineWidth',s)
% plot3([0,0],[-2,-2],[1,-1],color,'LineWidth',s)
% plot3([0,0],[1,-1],[-2,-2],color,'LineWidth',s)
% plot3([1,-1],[0,0],[-2,-2],color,'LineWidth',s)

%% mirror nodal lines
Theta=linspace(0,2*pi,100)';

x=0.6010*cos(Theta);
y=0.6010*sin(Theta);
z=2*ones(100,1);
plot3(x,y,z,color,'LineWidth',s)
plot3(x,z,y,color,'LineWidth',s)
plot3(z,x,y,color,'LineWidth',s)
plot3(x,y,-z,color,'LineWidth',s)
plot3(x,-z,y,color,'LineWidth',s)
plot3(-z,x,y,color,'LineWidth',s)

end

