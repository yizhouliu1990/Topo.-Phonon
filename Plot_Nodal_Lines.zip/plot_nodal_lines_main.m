clear
clc

a=113;b=12.0644;

% a=135;b=90;         % view for (001) projection
% a=135;b=35.2644     % view for (111) projection
% a=180;b=45;         % view for (110) projection

figure
hold on
plot_BZ(0.6)
plot_nodal_lines_bands12('r',1)
title('Topological nodal lines: bands 1-2')
view([a,b])


figure
hold on
plot_BZ(0.6)
plot_nodal_lines_bands34('r',1)
title('Topological nodal lines: bands 3-4')
view([a,b])


figure
hold on
plot_BZ(0.6)
plot_nodal_lines_bands45('r',1)
title('Topological nodal lines: bands 4-5')
view([a,b])


figure
hold on
plot_BZ(0.6)
plot_nodal_lines_bands56('r',1)
title('Topological nodal lines: bands 5-6')
view([a,b])

















