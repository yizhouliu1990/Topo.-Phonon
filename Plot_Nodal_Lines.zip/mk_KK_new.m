function KK_new=mk_KK_new(KK)

KK_new=[];
for i=1:size(KK,1)
    kx=KK(i,1);
    ky=KK(i,2);
    kz=KK(i,3);
    if (kx+ky+kz-3)*(kx+ky+kz+3)<=0 && (-kx+ky+kz-3)*(-kx+ky+kz+3)<=0 && ...
            (kx-ky+kz-3)*(kx-ky+kz+3)<=0 && (kx+ky-kz-3)*(kx+ky-kz+3)<=0 && ...
            abs(kx)<=2 && abs(ky)<=2 && abs(kz)<=2
        KK_new=[KK_new;[kx,ky,kz]];
    end
end

end